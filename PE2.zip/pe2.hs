module PE2 where

import Text.Printf

type Point = (Int, Int)
type Dimensions = (Int, Int)
type Vector = (Int, Int)

getRounded :: Double -> Double
getRounded x = read s :: Double
               where s = printf "%.2f" x

castIntToDouble x = (fromIntegral x) :: Double

-------------------------------------------------------------------------------------------
----------------------- DO NOT CHANGE ABOVE OR FUNCTION SIGNATURES-------------------------
------------- DUMMY IMPLEMENTATIONS ARE GIVEN TO PROVIDE A COMPILABLE TEMPLATE ------------
------------------- REPLACE THEM WITH YOUR COMPILABLE IMPLEMENTATIONS ---------------------
-------------------------------------------------------------------------------------------

-------------------------------------------------------------------------------------------------------------------------------
getVector :: String -> Vector
getVector d =  if (d=="East") then (1,0) 
        else if (d=="West") then (-1,0)
        else if (d=="North") then (0,1)
        else if (d=="South") then (0,-1)
        else if (d=="NorthEast") then (1,1)
        else if (d=="NorthWest") then (-1,1)
        else if (d=="SouthEast") then (1,-1)
        else if (d=="SouthWest") then (-1,-1)
        else  (0,0)

-------------------------------------------------------------------------------------------------------------------------------
getAllVectors :: [String] -> [Vector]
getAllVectors l = [getVector x|x<-l]

-------------------------------------------------------------------------------------------------------------------------------

pro i [] = []
pro i (x:xs) = [((fst (getVector x) + fst i),(snd (getVector x) + snd i))]  ++ (pro ((fst (getVector x) + fst i),(snd (getVector x) + snd i)) xs)

producePath :: Point -> [String] -> [Point]
producePath initial actions = pro initial ("Stay":actions)

-------------------------------------------------------------------------------------------------------------------------------
checkbound [] b = []
checkbound (x:xs) b = if (fst x<fst b) && (snd x <snd b) && (fst x>=0) && (snd x >=0) then [x]++ (checkbound xs b) else []

takePathInArea :: [Point] -> Dimensions -> [Point]
takePathInArea path (bx, by) = checkbound path (bx,by)

-------------------------------------------------------------------------------------------------------------------------------
is_same [] b = [b]
is_same (x:xs) b = if x == b then [] else (is_same xs b)

samelist path [] = []
samelist [] objects = objects 
samelist path (bb:b) = (is_same path bb) ++ (samelist path b)



remainingObjects :: [Point] -> Dimensions -> [Point] -> [Point]
remainingObjects path border objects = samelist (checkbound path border) objects

-------------------------------------------------------------------------------------------------------------------------------

correctpaths [] border objects = []
correctpaths (p:ps) border objects = if ((remainingObjects p border objects) ==[]) && ((p==(takePathInArea p border))) then [length(p)] ++ (correctpaths ps border objects) else [] ++ (correctpaths ps border objects)

my_sum_list [] = 0
my_sum_list (a:b)  = a + (my_sum_list b)


averageStepsInSuccess :: [[Point]] -> Dimensions -> [Point] -> Double
averageStepsInSuccess paths border objects =  getRounded (castIntToDouble (my_sum_list (y))) / (castIntToDouble (length (y))) where y = (correctpaths paths border objects)