module PE1 where

import Text.Printf
import Data.List

-- Type synonyms --
type Point = (Double, Double)
type Signal = (Double, Double, Double, Double)

-- This function takes a Double and rounds it to 2 decimal places as requested in the PE --
getRounded :: Double -> Double
getRounded x = read s :: Double
               where s = printf "%.2f" x

-------------------------------------------------------------------------------------------
----------------------- DO NOT CHANGE ABOVE OR FUNCTION SIGNATURES-------------------------
------------- DUMMY IMPLEMENTATIONS ARE GIVEN TO PROVIDE A COMPILABLE TEMPLATE ------------
------------------- REPLACE THEM WITH YOUR COMPILABLE IMPLEMENTATIONS ---------------------
-------------------------------------------------------------------------------------------

getDistance :: Point -> Point -> Double
getDistance (x1, y1) (x2, y2) = getRounded(sqrt(((x1) - (x2))**2 + ((y1)-(y2))**2))

-------------------------------------------------------------------------------------------


findAllDistances :: Point -> [Point] -> [Double]
findAllDistances b l = [getDistance b x| x<-l]

-------------------------------------------------------------------------------------------

findExtremes :: Point -> [Point] -> (Point, Point)
findExtremes b l =([i|(x_p,i)<-zip (findAllDistances b l) l,(minimum (findAllDistances b l))==x_p]!!0,[i|(x_p,i)<-zip (findAllDistances b l) l,(maximum (findAllDistances b l))==x_p]!!0)

-------------------------------------------------------------------------------------------
third (a,b,c,d) = c
fourth (a,b,c,d) = d
first (a,b,c,d) = a
second (a,b,c,d) =b
getSingleAction :: Signal -> String
getSingleAction signal = if (first signal)==(third signal) && (second signal)==(fourth signal) then "Stay"
    else  if (first signal)>(third signal) && (second signal)==(fourth signal) then "North"
    else  if (first signal)<(third signal) && (second signal)==(fourth signal) then "South"
    else  if (first signal)==(third signal) && (second signal)>(fourth signal) then "East"
    else  if (first signal)==(third signal) && (second signal)<(fourth signal) then "West"
    else  if (first signal)>(third signal) && (second signal)>(fourth signal) then "NorthEast"
    else  if (first signal)<(third signal) && (second signal)>(fourth signal) then "SouthEast"
    else  if (first signal)>(third signal) && (second signal)<(fourth signal) then "NorthWest"
    else  "SouthWest"

-------------------------------------------------------------------------------------------

getAllActions :: [Signal] -> [String]
getAllActions signals = [getSingleAction x | x<-signals]

-------------------------------------------------------------------------------------------
mycount [] s = 0
mycount (a:b) s = if a==s then 1+(mycount b s) else 0+(mycount b s)

numberOfGivenAction :: Num a => [Signal] -> String -> a
numberOfGivenAction signals action = mycount (getAllActions signals) action