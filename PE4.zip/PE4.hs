module PE4 where

import Data.List
import Data.Maybe

data Room = SeedStorage Int
          | Nursery Int Int
          | QueensChambers
          | Tunnel
          | Empty
          deriving Show

data Nestree = Nestree Room [Nestree] deriving Show

---------------------------------------------------------------------------------------------
------------------------- DO NOT CHANGE ABOVE OR FUNCTION SIGNATURES-------------------------
--------------- DUMMY IMPLEMENTATIONS ARE GIVEN TO PROVIDE A COMPILABLE TEMPLATE ------------
--------------------- REPLACE THEM WITH YOUR COMPILABLE IMPLEMENTATIONS ---------------------
---------------------------------------------------------------------------------------------

-- Note: undefined is a value that causes an error when evaluated. Replace it with
-- a viable definition! Name your arguments as you like by changing the holes: _

---------------------------------------------------------------------------------------------

-- Q1: Calculate the nutrition value of a given nest.

first_calculate Empty = 0
first_calculate Tunnel = 0
first_calculate (SeedStorage a) = a*3
first_calculate (Nursery a b) = a*7 + b*10 
first_calculate QueensChambers  = 0

calculate (Nestree a lst)  = (first_calculate a) + (send_calculate lst)

 
send_calculate [] = 0
send_calculate (x:xs) = (calculate x) + (send_calculate xs) 


nestNutritionValue :: Nestree -> Int
nestNutritionValue inp_tree = calculate inp_tree 

-- Q2: Calculate the nutrition value of each root-to-leaf path.

my_map a xs = [ a+x |x<-xs]

calculate2 (Nestree a []) = [first_calculate a]
calculate2 (Nestree a lst) = my_map (first_calculate a) (send_calculate2 lst)

send_calculate2 [] = []
send_calculate2 (x:xs) = (calculate2 x) ++ (send_calculate2 xs) 



pathNutritionValues :: Nestree -> [Int]
pathNutritionValues in_tree = calculate2 in_tree

-- Q3: Find the depth of the shallowest tunnel, if you can find one.

check_tunnel Tunnel = True
check_tunnel _ = False

calculate3 (Nestree a []) i = if (check_tunnel a) then [i] else [0]
calculate3 (Nestree a lst) i = if (check_tunnel a) then [i] else (send_calculate3 lst (i+1))

send_calculate3 [] i= []
send_calculate3 (x:xs) i= (calculate3 x i) ++ (send_calculate3 xs i) 


elimine [] = []
elimine (a:b) = if a==0 then (elimine b ) else [a]++(elimine b)

--result_tunnel a = if a == -1 then (listToMaybe []) else (listToMaybe [a])


shallowestTunnel :: Nestree -> Maybe Int
shallowestTunnel in_tree = if y == []  then (listToMaybe []) else (listToMaybe [minimum y]) where y= elimine (calculate3 in_tree 1)

-- Q4: Find the path to the Queen's Chambers, if such a room exists.

check_qs QueensChambers = True
check_qs _ = False

calculate4 (Nestree a []) i = if (check_qs a) then [i++[a]] else []
calculate4 (Nestree a lst) i = if (check_qs a) then [i++[a]] else (send_calculate4 lst (i++[a]))

send_calculate4 [] i= []
send_calculate4 (x:xs) i= (calculate4 x i) ++ (send_calculate4 xs i) 

give_nes (Nestree a lst) = a

pathToQueen :: Nestree -> Maybe [Room]
pathToQueen in_tree = if (length y) == 0 then Nothing else Just (init ((y)!!0))
                    where y =(calculate4 in_tree [])   

-- Q5: Find the quickest depth to the Queen's Chambers, including tunnel-portation :)
quickQueenDepth :: Nestree -> Maybe Int
quickQueenDepth in_tree = if (isNothing y) then Nothing
               else if (isNothing z) then Just ((length (fromJust(y))) + 1)
               else if (length (findIndices (check_tunnel) (fromJust y)) == 0) then Just ((length (fromJust(y))) + 1)
               else Just (fromJust(z)+((length (fromJust(y)))   - (last (findIndices (check_tunnel) (fromJust y)))))
                         where y=(pathToQueen in_tree)
                               z=(shallowestTunnel in_tree) 

-- Example nest given in the PDF.
exampleNest :: Nestree
exampleNest = 
  Nestree Tunnel [
    Nestree (SeedStorage 15) [
      Nestree (SeedStorage 81) []
    ],
    Nestree (Nursery 8 16) [
      Nestree Tunnel [
        Nestree QueensChambers [
          Nestree (Nursery 25 2) []
        ]
      ]
    ],
    Nestree Tunnel [
      Nestree Empty [],
      Nestree (SeedStorage 6) [
        Nestree Empty [],
        Nestree Empty []
      ]
    ]
  ]

-- Same example tree, with tunnels replaced by Empty
exampleNestNoTunnel :: Nestree
exampleNestNoTunnel = 
  Nestree Empty [
    Nestree (SeedStorage 15) [
      Nestree (SeedStorage 81) []
    ],
    Nestree (Nursery 8 16) [
      Nestree Empty [
        Nestree QueensChambers [
          Nestree (Nursery 25 2) []
        ]
      ]
    ],
    Nestree Empty [
      Nestree Empty [],
      Nestree (SeedStorage 6) [
        Nestree Empty [],
        Nestree Empty []
      ]
    ]
  ]
