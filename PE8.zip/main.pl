:- module(main, [is_movie_directed_by/2, total_awards_nominated/2, all_movies_directed_by/2, total_movies_released_in/3, all_movies_released_between/4]).
:- [kb].

% DO NOT CHANGE THE UPPER CONTENT, WRITE YOUR CODE AFTER THIS LINE

is_movie_directed_by(Title, Director):-movie(Title,Director,_,_,_,_).

total_awards_nominated(Title,Nominations):-movie(Title,Director,_,A,B,C), Nominations is A+B+C. 

all_movies_directed_by(Director,Movies):-findall(T,is_movie_directed_by(T, Director),Movies).

total_movies_released_in([],_,0).
total_movies_released_in([M|T],Year,Count):-total_movies_released_in(T,Year,Count1), movie(M,_,R,_,_,_), R=:=Year, Count is Count1+1.
total_movies_released_in([M|T],Year,Count):-total_movies_released_in(T,Year,Count1), movie(M,_,R,_,_,_), R=\=Year, Count is Count1.




all_movies_released_between([], _, _, []).

all_movies_released_between([M|T], MinYear, MaxYear, [M|Res]):- 
    all_movies_released_between(T,MinYear, MaxYear, Res), 
    movie(M,_,R,_,_,_),
    R >= MinYear,
    R =< MaxYear.


all_movies_released_between([M|T], MinYear, MaxYear, Res):- 
    all_movies_released_between(T,MinYear, MaxYear, Res), 
    movie(M,_,R,_,_,_),
    R<MinYear.
    
all_movies_released_between([M|T], MinYear, MaxYear, Res):- 
    all_movies_released_between(T,MinYear, MaxYear, Res), 
    movie(M,_,R,_,_,_),
    R>MaxYear.