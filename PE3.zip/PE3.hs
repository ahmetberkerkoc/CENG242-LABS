module PE3 where

-- can use these if you want to...
import Data.List
import Data.Maybe

data Private = Private { idNumber :: Int, height :: Int, timeToSwap :: Int } deriving Show

data Cell = Empty | Full Private deriving Show

type Area = [[Cell]] 

---------------------------------------------------------------------------------------------
------------------------- DO NOT CHANGE ABOVE OR FUNCTION SIGNATURES-------------------------
--------------- DUMMY IMPLEMENTATIONS ARE GIVEN TO PROVIDE A COMPILABLE TEMPLATE ------------
--------------------- REPLACE THEM WITH YOUR COMPILABLE IMPLEMENTATIONS ---------------------
---------------------------------------------------------------------------------------------


-- Note: undefined is a value that causes an error when evaluated. Replace it with
-- a viable definition! Name your arguments as you like by changing the holes: _


--------------------------
-- Part I: Warming up with Abstractions

-- bubbleHumans: Applying a parallel bubble step on integers.

ordering [] = []
ordering [a] = [a]
ordering (a:b:c) = if (b>a) then [b,a]++ordering(c) else [a]++ordering(b:c)

bubbleHumans :: [Int] -> [Int]
bubbleHumans height = ordering height

-- bubblePrivates: The same thing, but on privates with a key function and an asc/desc option.


ordering_asc fun [] = []
ordering_asc fun [a] = [a]
ordering_asc fun (a:b:c) = if ((fun b)<(fun a)) then [b,a]++(ordering_asc fun c) else [a]++(ordering_asc fun (b:c))


ordering_des fun [] = []
ordering_des fun [a] = [a]
ordering_des fun (a:b:c) = if ((fun b)>(fun a)) then [b,a]++(ordering_des fun c) else [a]++(ordering_des fun (b:c))

chose_order fun tf lst = if (tf==True) then (ordering_des fun lst) else  (ordering_asc fun lst)


bubblePrivates :: (Private -> Int) -> Bool -> [Private] -> [Private]
bubblePrivates fun tf lst = chose_order fun tf lst

-- sortPrivatesByHeight: Full sort via multiple bubble steps, calculate the sorting time too!
sortPrivatesByHeight :: [Private] -> ([Private], Int)

find_max a b = if a>b then a else b

ordering_private []  i = [Private 0 0 i]
ordering_private [a]  i = [a,(Private 0 0 i)]
ordering_private (a:b:c) i = if ((height b)>(height a)) then [b,a]++(ordering_private c (find_max i (find_max (timeToSwap a) (timeToSwap b)))) else [a]++(ordering_private (b:c) i)


result [] = ([],0)
result lst = (init lst, timeToSwap (last lst)) 

whole_sort (lst,i) a = if i == 0 then (lst,a) else whole_sort (result(ordering_private lst 0)) (i+a)
sortPrivatesByHeight lst = whole_sort (result (ordering_private lst 0)) 0




--------------------------
-- Part II: Squeezing your Brain Muscles

-- ceremonialFormation: Sorting again, but with multiple files. Don't forget the time!
give_height (Full (Private a b c)) = b
give_time (Full (Private a b c)) = c
give_ID (Full (Private a b c)) = a
is_full (Full _) = True 
is_full Empty = False

is_empty (Full _) = False 
is_empty Empty = True

ordering_private2 []  i = [Full (Private 0 0 i)]
ordering_private2 [a]  i = [a,Full (Private 0 0 i)]
ordering_private2 (a:b:c) i = if (is_empty (a)) && (is_empty (b)) then [a]++(ordering_private2 (b:c) i)
                              else if (is_empty (a)) && (is_full (b)) then [b,a]++(ordering_private2 c (find_max i (give_time b)))
                              else if (is_full (a)) && (is_empty (b)) then [a]++(ordering_private2 (b:c) i)
                              else if ((give_height b)>(give_height a)) then [b,a]++(ordering_private2 c (find_max i (find_max (give_time a) (give_time b)))) 
                              else [a]++(ordering_private2 (b:c) i)

result2 [] = ([],0)
result2 lst = (init lst, give_time (last lst)) 


whole_sort2 (lst,i) a = if i == 0 then (lst,a) else whole_sort2 (result2(ordering_private2 lst 0)) (i+a) 

ceremony [] = []
ceremony (a:b) = [y] ++ (ceremony b) where y =(whole_sort2 (result2 (ordering_private2 a 0)) 0)

last_result_2 [] i = i
last_result_2 (a:b) i = if i<(snd a) then last_result_2 b (snd a) else last_result_2 b i

last_result_1 [] = []
last_result_1 (a:b) = [fst a]++(last_result_1 b)

 

ceremonialFormation :: Area -> (Area, Int)
ceremonialFormation lst = ((last_result_1 y),(last_result_2 y 0)) where y = (ceremony lst) 

-- swapPrivates: Swap two arbitrary privates by ID if they are in the area. Big ouch!

find_oned_location [] x i = -1
find_oned_location (a:b) x i = if is_empty a then (find_oned_location  b x (i+1))
                                else if (give_ID a) == x  then i 
                                else (find_oned_location  b x (i+1))

find_twod_location [] x i = (-1,-1)
find_twod_location (a:b) x i = if y == -1 then (find_twod_location b x (i+1)) else (i,y) where y = (find_oned_location a x 0)

min_cor (x1,y1) (x2,y2) = if x1<x2 then (x1,y1)
        else if x1==x2 && y1<y2 then (x1,y1)
        else if x1==x2 && y1>y2 then (x2,y2)
        else (x2,y2)
        
max_cor (x1,y1) (x2,y2) = if x1>x2 then (x1,y1)
        else if x1==x2 && y1>y2 then (x1,y1)
        else if x1==x2 && y1<y2 then (x2,y2)
        else (x2,y2)

slicing f t lst = take (t - f ) (drop f lst)
swapping id1 id2 lst = list1++[list2++[((lst!!(fst(max_coordinates)))!!(snd (max_coordinates)))]++list3] ++ list4 ++[list5++[((lst!!(fst(min_cordinates)))!!(snd (min_cordinates)))]++list6] ++ list7  
    where coord1 = (find_twod_location lst id1 0) 
          coord2 = (find_twod_location lst id2 0) 
          min_cordinates = (min_cor coord1 coord2)
          max_coordinates = (max_cor coord1 coord2)
          l1 = length (lst!!(fst(min_cordinates)))
          l2 = length (lst!!(fst(max_coordinates)))
          list1 = take (fst(min_cordinates)) lst
          list2 = take (snd(min_cordinates))  (lst!!(fst(min_cordinates)))
          list3 = slicing ((snd min_cordinates) +1) (l1) (lst!!(fst(min_cordinates)))
          list4 = slicing ((fst min_cordinates)+1) (fst max_coordinates) lst
          list5 = take (snd(max_coordinates))  (lst!!(fst(max_coordinates)))
          list6 = slicing ((snd max_coordinates) +1) (l2) (lst!!(fst(max_coordinates)))
          list7 = slicing ((fst max_coordinates)+1) (length lst) lst


swapping1 id1 id2 lst = list1 ++ [list2++[list3]++list4++[list5]++list6] ++ list7
    where coord1 = (find_twod_location lst id1 0) 
          coord2 = (find_twod_location lst id2 0) 
          min_coordinates = (min_cor coord1 coord2)
          max_coordinates = (max_cor coord1 coord2)
          l1 = length (lst!!(fst(min_coordinates)))
          l2 = length (lst!!(fst(max_coordinates)))
          list1 = slicing 0 (fst min_coordinates) lst
          list2 = slicing 0 (snd min_coordinates) (lst!!(fst min_coordinates))
          list3 = (lst!!(fst max_coordinates))!!(snd max_coordinates)
          list4 = slicing (snd min_coordinates +1) (snd max_coordinates) (lst!!(fst min_coordinates))
          list5 = (lst!!(fst min_coordinates))!!(snd min_coordinates)
          list6 = slicing (snd max_coordinates +1) (l2) (lst!!(fst min_coordinates))
          list7 = slicing (fst min_coordinates +1) (length lst) lst 

swap_res id1 id2 lst= if (fst(find_twod_location lst id1 0) == fst(find_twod_location lst id2 0)) then swapping1 id1 id2 lst else (swapping id1 id2 lst) 
          
swap_check id1 id2 lst =  if ((find_twod_location lst id1 0) == (-1,-1) ||  (find_twod_location lst id2 0) == (-1,-1)) then lst 
               else swap_res id1 id2 lst

swapPrivates :: Int -> Int -> Area -> Area
swapPrivates id1 id2 lst = swap_check id1 id2 lst

-- Best of luck to you, friend and colleague!

